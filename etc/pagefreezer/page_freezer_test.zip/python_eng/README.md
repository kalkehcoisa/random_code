## Python Software Engineer Assignment

This assignment is in two parts: 
- the **first part** contains only a few _basic_ Python questions to assess your knowledge (basic.py); 
- the **second part** is an assignment where you will need to design, implement and test a solution to a problem. Please read the README FIRST file 

We are not expecting this exercise to take more than 2-3hrs at most.

**How to provide answers:**
Provide Python 2.7 files with your solutions in this same zip file, under the corresponding folders, and upload it in the form provided.


